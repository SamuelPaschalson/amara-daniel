import { useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';

const examples = [
  { name: 'Sophia', message: 'Counting down the days with you!' },
  { name: 'Chidi', message: 'May this next chapter be your most beautiful yet.' },
  { name: 'Leila & Tom', message: 'To a lifetime of slow mornings and loud laughter.' }
];

export default function Guestbook() {
  const [notes, setNotes] = useLocalStorage('amanda-nnanyelugo-guestbook', examples);
  const [form, setForm] = useState({ name: '', message: '' });
  const [notice, setNotice] = useState('');

  const submit = e => {
    e.preventDefault();
    if (form.name.trim().length < 2 || form.message.trim().length < 4) {
      setNotice('Please add your name and a short message.');
      return;
    }
    const ok = setNotes([...notes, { ...form, createdAt: new Date().toISOString() }]);
    setNotice(ok ? 'Your note has joined our guestbook.' : 'We could not save your note on this device.');
    if (ok) setForm({ name: '', message: '' });
  };

  return (
    <div className="guestbook-wrap">
      <div className="guestbook-list" aria-live="polite">
        {notes.length ? (
          notes.slice().reverse().map((n, i) => (
            <blockquote key={`${n.name}-${i}`}>
              “{n.message}”
              <cite>— {n.name}</cite>
            </blockquote>
          ))
        ) : (
          <p>No notes yet. Be the first to leave one.</p>
        )}
      </div>
      <form onSubmit={submit}>
        <div className="field">
          <label htmlFor="gb-name">Your name</label>
          <input
            id="gb-name"
            value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
          />
        </div>
        <div className="field">
          <label htmlFor="gb-message">Your message</label>
          <textarea
            id="gb-message"
            rows="5"
            value={form.message}
            onChange={e => setForm({ ...form, message: e.target.value })}
          />
        </div>
        {notice && <p role="status">{notice}</p>}
        <button className="button button--dark">
          <span>Sign the guestbook</span>
          <ArrowUpRight size={15} aria-hidden="true" />
        </button>
      </form>
    </div>
  );
}
