import { useEffect, useState } from 'react';
import { weddingData as d } from '../data/weddingData';

export default function EnvelopeIntro({ onOpen, onStart }) {
  const [opening, setOpening] = useState(false);

  useEffect(() => {
    if (!opening) return;
    const timer = window.setTimeout(onOpen, 2300);
    return () => window.clearTimeout(timer);
  }, [opening, onOpen]);

  const openInvitation = () => {
    if (opening) return;
    onStart();
    setOpening(true);
  };

  return (
    <div className={`envelope-intro ${opening ? 'is-opening' : ''}`}>
      <img
        className="envelope-portrait"
        src={d.featuredImage}
        alt=""
        aria-hidden="true"
      />
      <div className="envelope-intro__veil" />
      <div className="envelope-frame" aria-hidden="true">
        <span className="envelope-frame__corner envelope-frame__corner--tl" />
        <span className="envelope-frame__corner envelope-frame__corner--tr" />
        <span className="envelope-frame__corner envelope-frame__corner--bl" />
        <span className="envelope-frame__corner envelope-frame__corner--br" />
      </div>
      <span className="envelope-bloom envelope-bloom--top" aria-hidden="true" />
      <span className="envelope-bloom envelope-bloom--bottom" aria-hidden="true" />
      <div className="envelope-sparkles" aria-hidden="true">
        {Array.from({ length: 14 }, (_, i) => <i key={i} style={{ '--i': i }} />)}
      </div>

      <header className="envelope-intro__header">
        <p className="envelope-overline">You are warmly invited to</p>
        <p className="envelope-overline envelope-overline--sub">the wedding celebration of</p>
        <p className="envelope-script">
          <span>{d.couple.partnerOne}</span>
          <i>&</i>
          <span>{d.couple.partnerTwo}</span>
        </p>
        <span className="envelope-divider" aria-hidden="true"><i /><b>♥</b><i /></span>
        <p className="eyebrow">{d.day} · {d.date} · {d.location}</p>
      </header>

      <button
        className="envelope-stage"
        type="button"
        onClick={openInvitation}
        aria-label="Open Amanda and Nnanyelugo's wedding invitation"
        disabled={opening}
      >
        <span className="envelope-letter">
          <span className="letter-florals" aria-hidden="true" />
          <span className="eyebrow">Together with their families</span>
          <strong>{d.couple.partnerOne} <i>&</i> {d.couple.partnerTwo}</strong>
          <small>{d.dateShort} · {d.location}</small>
        </span>
        <span className="envelope-shell">
          <span className="envelope-lining" />
          <span className="envelope-pocket envelope-pocket--left" />
          <span className="envelope-pocket envelope-pocket--right" />
          <span className="envelope-pocket envelope-pocket--front" />
        </span>
        <span className="envelope-flap">
          <span className="envelope-flap__paper" />
        </span>
        <span className="envelope-florals" aria-hidden="true" />
        <span className="envelope-address">
          <strong>For our cherished guest</strong>
          <small>From {d.couple.partnerOne} & {d.couple.partnerTwo}</small>
        </span>
        <span className="wax-seal-ring" aria-hidden="true" />
        <span className="wax-seal">
          <span>{d.couple.partnerOne[0]}</span>
          <i>&</i>
          <span>{d.couple.partnerTwo[0]}</span>
        </span>
      </button>

      <footer className="envelope-intro__footer">
        <p className="envelope-tap">
          {opening ? 'Opening your invitation…' : <><span className="envelope-tap__hand" aria-hidden="true">✦</span> Tap the seal to open your invitation</>}
        </p>
        <div className="day-colors" aria-label="Colors of the day">
          {d.dressColors.map(([name, color]) => (
            <span key={name} title={name} style={{ background: color }} />
          ))}
        </div>
      </footer>
    </div>
  );
}