import { useState } from 'react';
import { Check, ArrowUpRight } from 'lucide-react';
import { submitRSVP } from '../services/rsvpService';
import { Button } from './UI';

const initial = {
  name: '',
  email: '',
  attendance: 'accepts',
  guests: '1',
  guestNames: '',
  meal: 'Standard',
  dietary: '',
  message: ''
};

export default function RSVPForm() {
  const [form, setForm] = useState(initial);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');
  const [error, setError] = useState('');

  const change = e => setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    const e = {};
    if (form.name.trim().length < 2) e.name = 'Please enter your full name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Please enter a valid email.';
    if (form.attendance === 'accepts' && (+form.guests < 1 || +form.guests > 6)) e.guests = 'Guest count must be between 1 and 6.';
    return e;
  };

  const submit = async e => {
    e.preventDefault();
    const v = validate();
    setErrors(v);
    if (Object.keys(v).length) return;
    setStatus('loading');
    setError('');
    try {
      await submitRSVP(form);
      setStatus('success');
    } catch (err) {
      setError(err.message);
      setStatus('error');
    }
  };

  if (status === 'success') {
    return (
      <div className="confirmation" role="status">
        <span className="confirmation-badge">
          <Check size={32} aria-hidden="true" />
        </span>
        <p className="eyebrow">RSVP received</p>
        <h2>Thank you, {form.name.split(' ')[0]}.</h2>
        <p>Your RSVP has been received.<br />We cannot wait to celebrate with you.</p>
        <Button to="/">Return to the celebration</Button>
      </div>
    );
  }

  return (
    <form className="rsvp-form" onSubmit={submit} noValidate>
      <div className="field">
        <label htmlFor="name">Full name</label>
        <input
          id="name"
          name="name"
          value={form.name}
          onChange={change}
          autoComplete="name"
          aria-invalid={!!errors.name}
        />
        {errors.name && <small>{errors.name}</small>}
      </div>

      <div className="field">
        <label htmlFor="email">Email</label>
        <input
          id="email"
          name="email"
          type="email"
          value={form.email}
          onChange={change}
          autoComplete="email"
          aria-invalid={!!errors.email}
        />
        {errors.email && <small>{errors.email}</small>}
      </div>

      <fieldset>
        <legend>Will you be joining us?</legend>
        <label className="radio">
          <input
            type="radio"
            name="attendance"
            value="accepts"
            checked={form.attendance === 'accepts'}
            onChange={change}
          />
          <span>Joyfully accepts</span>
        </label>
        <label className="radio">
          <input
            type="radio"
            name="attendance"
            value="declines"
            checked={form.attendance === 'declines'}
            onChange={change}
          />
          <span>Regretfully declines</span>
        </label>
      </fieldset>

      {form.attendance === 'accepts' && (
        <>
          <div className="form-row">
            <div className="field">
              <label htmlFor="guests">Number of guests</label>
              <select id="guests" name="guests" value={form.guests} onChange={change}>
                {[1, 2, 3, 4, 5, 6].map(n => <option key={n}>{n}</option>)}
              </select>
              {errors.guests && <small>{errors.guests}</small>}
            </div>
            <div className="field">
              <label htmlFor="meal">Meal preference</label>
              <select id="meal" name="meal" value={form.meal} onChange={change}>
                {['Standard', 'Vegetarian', 'Vegan', 'Other'].map(x => <option key={x}>{x}</option>)}
              </select>
            </div>
          </div>
          <div className="field">
            <label htmlFor="guestNames">Guest names</label>
            <input
              id="guestNames"
              name="guestNames"
              value={form.guestNames}
              onChange={change}
              placeholder="As shown on their invitation"
            />
          </div>
          <div className="field">
            <label htmlFor="dietary">Dietary restrictions</label>
            <input
              id="dietary"
              name="dietary"
              value={form.dietary}
              onChange={change}
              placeholder="Allergies or requirements"
            />
          </div>
        </>
      )}

      <div className="field">
        <label htmlFor="message">A note for us</label>
        <textarea id="message" name="message" rows="4" value={form.message} onChange={change} />
      </div>

      {error && <p className="form-error" role="alert">{error}</p>}

      <button className="button button--dark submit" disabled={status === 'loading'}>
        <span>{status === 'loading' ? 'Sending your reply…' : 'Send RSVP'}</span>
        <ArrowUpRight size={15} aria-hidden="true" />
      </button>
    </form>
  );
}
